#ifndef MONSTER_H
#define MONSTER_H

#include "role.h"

class Monster : public Role {
public:
    // Although this class is empty, but maybe i will add some special skill for monster later
    Monster() {}
    ~Monster() {}
};

#endif // MONSTER_H
